# Wasl Connect

Independent web connection test service.

## Local run

```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

The service exposes:
- `/` web interface
- `/health` health check
- `/ws` WebSocket connection
